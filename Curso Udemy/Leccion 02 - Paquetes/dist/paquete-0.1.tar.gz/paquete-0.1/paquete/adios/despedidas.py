# modulo con funciones que saludan

def despedirse():
    print("Adiós te estoy despidiendo desde la función saludar del módulo saludos")

class Despedida():
    def __init__(self):
        print("Adiós te estoy despidiendo desde el init de la clase Despedida")