from setuptools import setup

setup(
    name="paquete",
    version="0.1",
    description="Este es un paquete de ejemplo",
    authot="Pablo Pantoja",
    author_email="pablopantoja1985@gmail.com",
    url="...",
    scripts=[],
    packages=["paquete","paquete.adios","paquete.hola"]
)